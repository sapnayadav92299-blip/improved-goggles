package dev.lelonio.square.ui.components

import android.os.SystemClock
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.delay
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.systemGestureExclusion
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * A row that scrolls sideways fading out at an edge it has more beyond,
 * rather than ending in a cut through whatever is passing it: a chip or a
 * lit pill sliced at the edge reads as a mistake (#166). Each edge fades only
 * while there is more of the row past it, and only as far as there is.
 */
fun Modifier.horizontalEdgeFade(state: ScrollState, width: Dp = 24.dp): Modifier = this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        val fade = width.toPx()
        if (fade <= 0f || size.width <= 0f) return@drawWithContent
        val start = (state.value / fade).coerceIn(0f, 1f)
        val end = ((state.maxValue - state.value) / fade).coerceIn(0f, 1f)
        if (start <= 0f && end <= 0f) return@drawWithContent
        val share = (fade / size.width).coerceAtMost(0.5f)
        drawRect(
            brush = Brush.horizontalGradient(
                0f to Color.Black.copy(alpha = 1f - start),
                share to Color.Black,
                1f - share to Color.Black,
                1f to Color.Black.copy(alpha = 1f - end),
            ),
            blendMode = BlendMode.DstIn,
        )
    }

/**
 * For a row that scrolls sideways from one edge of the screen to the other:
 * keeps the system's back gesture off it. With gesture navigation a drag that
 * starts at either edge is "back", and a row of chips or presets runs right to
 * both, so trying to scroll it from where it starts left the tab or closed the
 * page instead (#172). The row is short, well inside the room Android allows an
 * app to take from each edge, and the back gesture still works everywhere else.
 */
val SideScrollNoBack: Modifier = Modifier.systemGestureExclusion()

/**
 * The colour the top and bottom fades (and the pinned headings) melt into.
 * SquareApp sets it from the playing cover; black until there is one.
 */
object FadeTone {
    var color by androidx.compose.runtime.mutableStateOf(androidx.compose.ui.graphics.Color.Black)
}

/**
 * Soft edges for a row that scrolls sideways: whatever runs off either side
 * melts away instead of being cut. Always on, and narrow enough to sit inside
 * the row's own start padding, so a row at rest is not dimmed.
 */
fun Modifier.sideFade(width: Dp = 18.dp): Modifier = this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        val fade = width.toPx()
        if (fade <= 0f || size.width <= 0f) return@drawWithContent
        val share = (fade / size.width).coerceAtMost(0.5f)
        drawRect(
            brush = Brush.horizontalGradient(
                0f to Color.Black.copy(alpha = 0f),
                share to Color.Black,
                1f - share to Color.Black,
                1f to Color.Black.copy(alpha = 0f),
            ),
            blendMode = BlendMode.DstIn,
        )
    }

/** A LazyRow with [sideFade] on it: every shelf and chip row in the app. */
@androidx.compose.runtime.Composable
fun FadeLazyRow(
    modifier: Modifier = Modifier,
    state: androidx.compose.foundation.lazy.LazyListState = androidx.compose.foundation.lazy.rememberLazyListState(),
    contentPadding: androidx.compose.foundation.layout.PaddingValues = androidx.compose.foundation.layout.PaddingValues(0.dp),
    reverseLayout: Boolean = false,
    horizontalArrangement: androidx.compose.foundation.layout.Arrangement.Horizontal =
        if (!reverseLayout) androidx.compose.foundation.layout.Arrangement.Start else androidx.compose.foundation.layout.Arrangement.End,
    verticalAlignment: androidx.compose.ui.Alignment.Vertical = androidx.compose.ui.Alignment.Top,
    flingBehavior: androidx.compose.foundation.gestures.FlingBehavior =
        androidx.compose.foundation.gestures.ScrollableDefaults.flingBehavior(),
    userScrollEnabled: Boolean = true,
    /** Drifts sideways by itself; a touch stops it, and it starts again 3 s after the finger lets go. */
    autoScroll: Boolean = false,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit,
) {
    val held = remember { mutableStateOf(false) }
    if (autoScroll) AutoMarquee(state, held)
    androidx.compose.foundation.lazy.LazyRow(
        modifier = modifier
            .then(
                if (autoScroll) {
                    Modifier.pointerInput(Unit) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                            held.value = true
                            do {
                                val event = awaitPointerEvent(PointerEventPass.Initial)
                            } while (event.changes.any { it.pressed })
                            held.value = false
                        }
                    }
                } else {
                    Modifier
                },
            )
            .sideFade(),
        state = state,
        contentPadding = contentPadding,
        reverseLayout = reverseLayout,
        horizontalArrangement = horizontalArrangement,
        verticalAlignment = verticalAlignment,
        flingBehavior = flingBehavior,
        userScrollEnabled = userScrollEnabled,
        content = content,
    )
}

/**
 * Soft top and bottom edges for a list: rows melt away into the pane instead
 * of being cut through the middle of a line. A long, eased ramp (not a short
 * linear one) so it reads as frosted glass thickening toward the edge.
 */
fun Modifier.verticalEdgeFade(top: Dp = 56.dp, bottom: Dp = 64.dp): Modifier = this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        val h = size.height
        if (h <= 0f) return@drawWithContent
        val t = (top.toPx() / h).coerceAtMost(0.45f)
        val b = (bottom.toPx() / h).coerceAtMost(0.45f)
        drawRect(
            brush = Brush.verticalGradient(
                0f to Color.Black.copy(alpha = 0f),
                t * 0.35f to Color.Black.copy(alpha = 0.10f),
                t * 0.70f to Color.Black.copy(alpha = 0.50f),
                t to Color.Black,
                1f - b to Color.Black,
                1f - b * 0.65f to Color.Black.copy(alpha = 0.55f),
                1f - b * 0.30f to Color.Black.copy(alpha = 0.12f),
                1f to Color.Black.copy(alpha = 0f),
            ),
            blendMode = BlendMode.DstIn,
        )
    }

/**
 * Slowly moves a row sideways on its own, always to the left.
 * Stops the moment [held] says a finger is on it or the row is moving for any
 * other reason (a drag, a fling), and carries on 3 seconds after that.
 */
@Composable
private fun AutoMarquee(state: LazyListState, held: State<Boolean>) {
    val density = LocalDensity.current
    LaunchedEffect(state) {
        val speed = with(density) { 34.dp.toPx() }
        var resumeAt = SystemClock.uptimeMillis() + 1500L
        var last = 0L
        while (true) {
            val frame = withFrameNanos { it }
            val dt = if (last == 0L) 0f else (frame - last) / 1_000_000_000f
            last = frame
            val now = SystemClock.uptimeMillis()
            if (held.value || state.isScrollInProgress) {
                resumeAt = now + 3000L
                continue
            }
            if (now < resumeAt) continue
            if (!state.canScrollForward) {
                delay(500)
                continue
            }
            // Always the same way: the row moves left, for good.
            state.scrollBy(speed * dt.coerceAtMost(0.05f))
        }
    }
}

/**
 * A black fade over the top of a list, there only once the rows have started
 * to scroll away under it: at rest the first row is untouched, and as the list
 * moves up the rows melt into black before they reach the header instead of
 * being cut off by it. [strength] is 0 to 1 and is read as the list draws.
 */
fun Modifier.topScrollFade(height: Dp = 52.dp, strength: () -> Float): Modifier = this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        val s = strength().coerceIn(0f, 1f)
        if (s <= 0f || size.height <= 0f) return@drawWithContent
        val t = (height.toPx() / size.height).coerceAtMost(0.45f)
        drawRect(
            brush = Brush.verticalGradient(
                0f to Color.Black.copy(alpha = 1f - s),
                t * 0.35f to Color.Black.copy(alpha = 1f - 0.9f * s),
                t * 0.70f to Color.Black.copy(alpha = 1f - 0.5f * s),
                t to Color.Black,
                1f to Color.Black,
            ),
            blendMode = BlendMode.DstIn,
        )
    }
