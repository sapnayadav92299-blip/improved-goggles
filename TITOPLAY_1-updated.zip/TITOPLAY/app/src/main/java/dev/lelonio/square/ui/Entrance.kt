package dev.lelonio.square.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * The first rows of a list arriving one after another, each rising a little as
 * it fades in, instead of all appearing at once.
 *
 * Only once per row: [seen] belongs to the list, and a row that comes back into
 * view after a scroll is not in it as new, so nothing replays while scrolling.
 * Only the first [maxRows], which are the ones on screen when a page opens.
 */
fun Modifier.staggeredEntrance(index: Int, seen: MutableSet<Int>, maxRows: Int = 12): Modifier = composed {
    val animate = remember { index < maxRows && seen.add(index) }
    if (!animate) {
        Modifier
    } else {
        val progress = remember { Animatable(0f) }
        LaunchedEffect(Unit) {
            delay(index * 40L)
            progress.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
        }
        Modifier.graphicsLayer {
            alpha = progress.value
            translationY = (1f - progress.value) * 22.dp.toPx()
        }
    }
}
