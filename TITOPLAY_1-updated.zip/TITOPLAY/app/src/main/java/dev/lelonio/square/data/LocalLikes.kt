package dev.lelonio.square.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * The songs the listener has hearted on this phone, whatever account is or is
 * not signed in: the library's "Liked on this phone" shelf.
 *
 * Whole tracks rather than addresses, so the shelf can list them with their
 * names and covers without asking any service, and offline. Newest first.
 */
class LocalLikes(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    private val _tracks = MutableStateFlow(load())
    val tracks: StateFlow<List<CatalogTrack>> = _tracks.asStateFlow()

    fun isLiked(uri: String?): Boolean = uri != null && _tracks.value.any { it.uri == uri }

    /** Likes the track, or takes it back out when it is already liked. True when it is liked now. */
    fun toggle(track: CatalogTrack): Boolean {
        val current = _tracks.value
        val nowLiked = current.none { it.uri == track.uri }
        val updated = if (nowLiked) listOf(track) + current else current.filterNot { it.uri == track.uri }
        _tracks.value = updated
        save(updated)
        return nowLiked
    }

    fun remove(uri: String) {
        val updated = _tracks.value.filterNot { it.uri == uri }
        if (updated.size == _tracks.value.size) return
        _tracks.value = updated
        save(updated)
    }

    private fun load(): List<CatalogTrack> = runCatching {
        val array = JSONArray(prefs.getString(KEY_TRACKS, "[]"))
        (0 until array.length()).mapNotNull { index ->
            val o = array.optJSONObject(index) ?: return@mapNotNull null
            val uri = o.optString("uri").takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            CatalogTrack(
                uri = uri,
                name = o.optString("name"),
                artist = o.optString("artist"),
                artistUri = o.optString("artistUri").takeIf { it.isNotEmpty() },
                album = o.optString("album"),
                albumUri = o.optString("albumUri").takeIf { it.isNotEmpty() },
                durationMs = o.optLong("durationMs"),
                explicit = o.optBoolean("explicit"),
                artworkUrl = o.optString("artworkUrl").takeIf { it.isNotEmpty() },
            )
        }
    }.getOrDefault(emptyList())

    private fun save(tracks: List<CatalogTrack>) {
        val array = JSONArray()
        tracks.forEach { t ->
            array.put(
                JSONObject()
                    .put("uri", t.uri)
                    .put("name", t.name)
                    .put("artist", t.artist)
                    .put("artistUri", t.artistUri ?: "")
                    .put("album", t.album)
                    .put("albumUri", t.albumUri ?: "")
                    .put("durationMs", t.durationMs)
                    .put("explicit", t.explicit)
                    .put("artworkUrl", t.artworkUrl ?: ""),
            )
        }
        prefs.edit().putString(KEY_TRACKS, array.toString()).apply()
    }

    companion object {
        /** The shelf's own address in the library, like the local files' one. */
        const val CONTEXT_URI = "local:likes"
        private const val FILE_NAME = "local_likes"
        private const val KEY_TRACKS = "tracks"
    }
}
